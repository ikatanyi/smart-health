/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.smarthealth.config;

/**
 *
 * @author Kelsas
 */
public interface QueueConstants {
    public static String JOURNAL_QUEUE="journal-queue";
}
