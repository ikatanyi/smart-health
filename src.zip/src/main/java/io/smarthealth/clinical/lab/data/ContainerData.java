package io.smarthealth.clinical.lab.data;

import lombok.Data;

/**
 *
 * @author Kennedy.Imbenzi
 */
@Data
public class ContainerData {
    private Long id;
    private String container;
}
