package io.smarthealth.administration.app.domain;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author kelsas
 */
public interface AddressRepository extends JpaRepository<Address, Long> {

}
