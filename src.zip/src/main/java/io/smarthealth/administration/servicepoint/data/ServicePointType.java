package io.smarthealth.administration.servicepoint.data;

/**
 *
 * @author Kelsas
 */
public enum ServicePointType {
    Consultation,
    Laboratory,
    Pharmacy,
    Radiology,
    Procedures,
    Triage,
    Others
}