package io.smarthealth.accounting.invoice.domain;

import lombok.Data;

/**
 *
 * @author Kelsas
 */
@Data
public class Discount {
    private Long id;
    private Double amount;
            
}
