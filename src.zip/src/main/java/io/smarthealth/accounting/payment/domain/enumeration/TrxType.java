package io.smarthealth.accounting.payment.domain.enumeration;

/**
 *
 * @author Kelsas
 */
public enum TrxType {
    charge,
    payment,
    refund,
    adjustment,
    invoicing,
    billing
}
