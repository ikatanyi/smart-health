 package io.smarthealth.accounting.payment.domain.enumeration;

/**
 *
 * @author Kelsas
 */
public enum PaymentStatus {
    Successful,
    Failed,
    Pending
}
