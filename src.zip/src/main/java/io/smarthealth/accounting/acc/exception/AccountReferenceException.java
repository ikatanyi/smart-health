package io.smarthealth.accounting.acc.exception;

 
@SuppressWarnings("WeakerAccess")
public class AccountReferenceException extends RuntimeException {
}
