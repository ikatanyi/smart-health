package io.smarthealth.accounting.acc.exception;

 
@SuppressWarnings("WeakerAccess")
public final class AccountNotFoundException extends RuntimeException {
}
