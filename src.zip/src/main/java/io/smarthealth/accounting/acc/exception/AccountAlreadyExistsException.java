package io.smarthealth.accounting.acc.exception;

 
@SuppressWarnings("WeakerAccess")
public final class AccountAlreadyExistsException extends RuntimeException {
}
