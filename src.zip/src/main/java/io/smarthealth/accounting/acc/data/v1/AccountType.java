package io.smarthealth.accounting.acc.data.v1;

@SuppressWarnings({"unused"})
public enum AccountType {
    ASSET,
    LIABILITY,
    EQUITY,
    REVENUE,
    EXPENSE
}
